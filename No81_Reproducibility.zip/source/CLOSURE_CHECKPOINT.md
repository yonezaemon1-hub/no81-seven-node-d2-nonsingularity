# Closure checkpoint: exact centered D=2 result through seven nodes
2026-11-20 JST. PRIVATE / HOLD. NOVELTY INCONCLUSIVE / REFERENCES PARTIAL / NOT HUMAN PEER REVIEWED / All rights reserved. No research number assigned. This is a proposed audit scope, not a formal v0.8 freeze, publication, or independent mathematical audit.

## 1. Exact target and boundary
Claim for independent audit: for distinct positive rational radii, the centered D=2 logarithmic coefficient matrix for 3, 5, or 7 nodes is nonsingular. For nine nodes and beyond, the corresponding universal rational claim remains open in this project. We deliberately do not extend the claim merely because additional necessary congruences can be derived. The earlier unrestricted conjecture (all degrees, all distinct rational nodes) remains open.

For nodes b_0=0,b_1,...,b_s, N=3s, put A[n,(i,j)]=b_i^(n-j)/(n-j) if n>j and 0 otherwise (1<=n<=N,1<=i<=s,0<=j<=2). Common nonzero rational scaling changes A by invertible diagonal factors, and permutation changes the column order. Thus centered rational radii can be normalized to primitive positive integers.

## 2. Direct D=2 reduction, including the converse
Given a coefficient vector define P_i(x)=sum_j u_ij x^(2-j), P_0=-sum_{i>=1}P_i and f=sum_i P_i(x) log(1-b_i/x). Here logs are formal Laurent series at infinity. A kernel vector is equivalent to f=O(x^(1-N)). Write B(x)=prod_i(x-b_i). Third differentiation of sum_i P_i log(x-b_i)=f gives a rational function Q/B^3; the poles have order at most 3, and decay at infinity is O(x^(-N-2)), so deg Q<=1. If Q=0, uniqueness of partial fractions forces all P_i=0. In detail, for Q=q0+q1 x at node b, write the three principal coefficients as c0/(x-b)^3+c1/(x-b)^2+c2/(x-b); then P_b=c0/2-c1(x-b)+c2(x-b)^2/2, since the third derivatives of log(x-b), (x-b)log(x-b), (x-b)^2 log(x-b) have constants 2,-1,2 respectively. The polynomial parts of (x-b)^j log(1-b/x) are 0,-b,-bx+3b^2/2 for j=0,1,2. Hence the constant and linear parts of f are sum_b (b c1+3b^2 c2/4) and -sum_b b c2/2. Since Q/B^3 decays faster than x^-3, sum_b(b c2+c1)=0 and sum_b(b^2 c2+2b c1+c0)=0. Those parts equal -sum_b(3c0/4+b c1/2) and sum_b c1/2.

Put g_b=1/B'(b)^3, c_b=-3g_b sum_{v!=b}1/(b-v). Then c0=Q(b)g_b and c1=q1 g_b+Q(b)c_b. Define G=sum g_b, C=sum b c_b, R=sum c_b, T=sum b g_b, U=sum b^2 c_b. The residue matrix in the constant/linear order is therefore

    M = [[-(3G+2C)/4, -(5T+2U)/4], [R/2, (G+C)/2]].

Conversely take Q in ker M, define P_b as above from the partial fractions and do not assume sum P_b=0. For S=sum P_b, formal differentiation of S log x+f gives Q/B^3. The third derivative of S log x has terms only in x^-1,x^-2,x^-3, with nonzero coefficients multiplying the corresponding coefficients of S. The third derivative of the Laurent part f has no such terms (the polynomial part has degree <=1, and negative powers begin at x^-4 after differentiation). Thus the decay forces S=0. Since Q belongs to ker M the polynomial part of f vanishes, and termwise differentiation forces f=O(x^(1-N)). This reconstructs an original kernel vector, with inverse given by Q. Hence ker A and ker M are linearly isomorphic over any characteristic-zero field. This is a direct D=2 rederivation rather than reliance on all earlier arbitrary-degree claims.

For odd centered nodes, B is odd, g_b is even under reflection, c_b is odd, so R=T=U=0. The condition det A != 0 is equivalent to (G+C)(3G+2C) != 0. Let y_i=a_i^2, g0=(-1)^m/(prod y_i)^3, and use B'(a_i)=2y_i prod_{j!=i}(y_i-y_j). The normalized branches are

    N_F=8+sum_i R_i(7+12T_i), N_H=2+sum_i R_i(1+2T_i),
    R_i=prod_{j!=i}(y_j/(y_j-y_i))^3, T_i=sum_{j!=i} y_i/(y_i-y_j).

They equal 8(G+C)/g0 and 2(3G+2C)/(3g0), respectively. Thus their simultaneous nonvanishing is exactly the desired regularity.

## 3. Closed candidate: m=1,2,3
m=1 gives the constants 15,3. For m=2 the exact factorizations of the normalized branches have common factor X^2-3XY+Y^2, where X,Y are distinct positive rational squares; its ratio roots (3±sqrt(5))/2 are irrational. The other factors 5(X-Y)^2+8XY and 3(X-Y)^2+4XY are positive. The supporting previous symbolic certificate was replayed.

For m=3, use the attached 2-adic, small-prime and global factorization proofs, all with their exact symbolic certificates replayed. They give the necessary factorization, with d=gcd(b,c), e=gcd(a,c), f=gcd(a,b):

    a=ef*u^2, b=df*v^2, c=de*w^2,
    c^2-b^2=g*eps_a*d^2*u^3,
    c^2-a^2=g*eps_b*e^2*v^3,
    b^2-a^2=g*eps_c*f^2*w^3.

Exactly one epsilon equals 2, the others 1. Here g is the common gcd of the three squared differences. Dividing these three differences by d^2,e^2,f^2 respectively, then MULTIPLYING the resulting equations by u^4,v^4,w^4 respectively and adding the first and third minus the second gives eps_a*u^7+eps_c*w^7=eps_b*v^7. Primitivity of a,b,c implies gcd(u,v,w)=1. The external Darmon–Merel theorem excludes every nontrivial primitive solution of X^7+Y^7=2Z^7, allowing signed variables to move the even term to the RHS. The positive original variables must all equal 1 and eps_b=2. Remaining d^2-e^2=e^2-f^2=g>0, and writing t=f^2,h=g gives squared radii t(t+h), t(t+2h), (t+h)(t+2h). The attached completion proof and certificate give explicit positive numerator polynomials for both scalars with t,h>0, a contradiction. Therefore no further seven-node cases remain in the proposed proof. The all-prime support calculation and arithmetic translation, and the external theorem application, still need independent audit; finite sample verification alone does not certify them. Darmon–Merel, J. reine angew. Math. 490 (1997), 81–100, doi:10.1515/crll.1997.490.81, Main Theorem(1), author manuscript https://perso.imj-prg.fr/loic-merel/wp-content/uploads/merel-pub/winding.pdf (pp. 1–2; page 2 image checked in this turn). No independent reproduction of its external proof.

## 4. Actual nine-node open equation, not another sieve
For m=4 set D0=prod_{i<j}(y_i-y_j)^4, delta_i=prod_{j!=i}(y_i-y_j), tau_i=sum_{l!=i}prod_{j!=i,l}(y_i-y_j). Define the integral homogeneous polynomials

    P_(k,b,c)=k D0 - sum_i prod_{j<l; j,l!=i}(y_j-y_l)^4
                     * prod_{j!=i} y_j^3 * (b delta_i+c y_i tau_i).

For k,b,c=(8,7,12) and (2,1,2) these satisfy P=D0*N, respectively. Every term has degree 24 in y; both have 1265 monomials after expansion. The exact factor_list over QQ[y_1,...,y_4] returned one degree-24 factor for each; their polynomial gcd is constant. This is a calculation using SymPy, not an independently certified irreducibility proof and not a rational-point exclusion. Substitution y_i=a_i^2 produces degree-48 projective equations in radii. No assertion of irreducibility after that substitution. By section 2, a counterexample to nine-node regularity is exactly a rational zero of either of these equations with distinct nonzero positive radii; common scale is irrelevant. Equivalently these are rational-point questions on projective hypersurfaces, with the zero-radius and coincident-square loci discarded. A solution of the unrestricted squared-variable equation alone is not enough: the squares must be rational squares, up to common scaling. No general theorem excluding those rational points was obtained. The previous p-adic singular examples rule out a blanket argument based only on 2-adic nonvanishing. The previous generalized Fermat reduction needs additional prime-exponent conditions and is not equivalent to this full equation.

## 5. Scope decision
Proposed research closure is the exact centered D=2 theorem through seven nodes, without claiming nine-node regularity or the unrestricted conjecture. Keep nine-node computations as separate unfinished research records without increasing the research number. If pursuing nine nodes further, the target must be the rational points of the explicit equations in section 4, not further screening percentage. No new case-count or benchmark claimed. Independent mathematical audit, Windows replay, full historical verifier replay, novelty search, formal freeze and publication not performed. The author has not authorized this scope as a final numbered publication. The immutable original v0.7 is included without modification; its SHA256 is ef40748e44e13280e00b4db496a3296119fa1adb2659afb869e5865f3765c6f4. All new check logs accompany this note.
