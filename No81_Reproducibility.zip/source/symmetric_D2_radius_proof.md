# Radius collision certificates for odd centrally symmetric D=2 configurations
PRIVATE / HOLD — NOVELTY INCONCLUSIVE / REFERENCES PARTIAL / NOT HUMAN PEER REVIEWED / All rights reserved

Dependency: frozen v0.7 SHA256 ef40748e44e13280e00b4db496a3296119fa1adb2659afb869e5865f3765c6f4 and the D=2 moment identity in d2_moment_reduction.py. The necessary residue reduction suffices; its converse is not needed. No independent audit.

Let the distinct integer nodes be {0, ±a_i : 1<=i<=m}, with positive distinct radii a_i. Rational configurations can be cleared of denominators. Write B(X)=X product_i(X^2-a_i^2), g(b)=1/B'(b)^3, c(b)=-3g(b) sum_{v!=b}1/(b-v), G=sum g(b), C=sum b c(b). Reflection gives R=T=U=0 in the D=2 moment formula, hence det M=-(G+C)(3G+2C)/8. Nonzero det M suffices for nonzero det A.

## Radius formulas
Write y_i=a_i^2, P(Y)=product_i(Y-y_i), g_0=P(0)^(-3), g_i=[8 y_i^3 P'(y_i)^3]^(-1). Because B'(±a_i)=2y_i P'(y_i), the exact expressions are G=g_0+2 sum_i g_i and C=-sum_i g_i(9+12 y_i sum_{j!=i}1/(y_i-y_j)). Indeed the reciprocal sum at +a_i is 3/(2a_i)+2a_i sum_{j!=i}1/(y_i-y_j). Both scalars depend only on squared radii.

## Theorem A (one zero squared radius)
Suppose p>5, exactly one a_i is divisible by p, e=v_p(a_i)>0, and the other squared radii are nonzero and pairwise distinct modulo p. Then v_p(G+C)=v_p(3G+2C)=-6e.

Proof: only the cluster {0,±a_i} has collisions. Put a_i=p^e u, E=product of (0-v) over all external nodes, a p-adic unit. Multiplying g at the three cluster nodes by p^(6e) gives residues E^(-3)u^(-6) times -1,1/8,1/8, respectively. These follow directly by splitting B into X(X^2-a_i^2) and its unit external factor. The internal reciprocal sums at ±a_i are ±3/(2a_i); external sums are p-integral. Hence p^(6e)G is congruent to -3/4 times E^(-3)u^(-6), and p^(6e)C to -9/8 times that unit. Outside contributions vanish modulo p after scaling. The two scalar residues are -15/8 and -9/2 times the unit, nonzero for p>5. QED.

## Theorem B (one nonzero squared-radius pair)
Suppose p>3, every radius is a unit, and exactly one unordered pair of squared radii agrees modulo p. Put e=v_p(a_i^2-a_j^2)>0 for that pair. Then v_p(G+C)=v_p(3G+2C)=-4e.

Proof: choose signs a,b for the two radii so a=b mod p. As a+b is a unit, v_p(a-b)=e. The only collision classes are {a,b} and {-a,-b}. Set delta=a-b=p^e u and E=product_{v outside {a,b}}(a-v), a unit. The external product at b agrees with E mod p. Thus p^(3e)g(a), p^(3e)g(b) reduce to u^(-3)E^(-3), -u^(-3)E^(-3). The leading reciprocal sums are delta^(-1), -delta^(-1); consequently p^(4e)c at both nodes reduces to -3u^(-4)E^(-3). Their contribution to p^(4e)C is -6a u^(-4)E^(-3), and reflection doubles it, because b c(b) is even. Isolated nodes contribute zero modulo p after scaling. Meanwhile p^(4e)G is zero modulo p. Therefore the two leading scalar residues are -12a u^(-4)E^(-3) and twice that value, both units for p>3. QED.

## Corollary (symmetric S-unit restriction)
Fix at least two distinct positive integer radii b_i. Extend by a/q in lowest terms (q>0), up to sign and excluding any repeated radius or zero. Let S consist of primes <=5 and prime divisors of all b_i and all b_i^2-b_j^2. If the extended matrix is singular, then a and every a±q b_i has prime support in S. Indeed a prime outside S dividing any of these quantities cannot divide q; scaled fixed radii qb_i remain nonzero and distinct up to sign modulo p. Theorem A applies to a prime dividing a; Theorem B applies to one dividing a±q b_i. Both contradict singularity. In particular ratios of three distinct linear forms among a,a±qb_i lead to an S-unit equation by the previous fixed-core argument. This is a necessary constraint, not a general nonsingularity proof. No general S-unit solver has been run.

## Checks
Run symmetric_D2_radius_certificate.py in the same directory as d2_moment_reduction.py and frozen v0.7 ZIP (Python and SymPy). Exact rational-root exclusion for 38 numerator polynomials (two per fixed radius b=2..20 with radii 1,b,x), no admissible rational roots. Primitive positive integer radii: 3472 triples with max<=30 and 1745 quadruples with max<=16; both scalars nonzero in all 5217. Primes 5<=p<100: 17545 configuration-prime valuation checks; 5161 configurations covered by A/B, 56 not. Exact frozen reduced determinant and integer-cleared original determinant checked for all 56 uncovered cases. 200 radius/moment comparisons. 48 constructed depth checks (e=1..6). The 38 numerator checks use the complete rational-root routine over QQ, not a bounded search. No general seven- or nine-node theorem. Old five-node symmetric and S-unit certificates were replayed separately; full previous suite not rerun. No novelty check, independent audit or Windows test in this step.
