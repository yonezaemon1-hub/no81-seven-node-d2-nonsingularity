# Small-prime nonvanishing for centrally symmetric seven-node configurations (D=2)

PRIVATE / HOLD — NOVELTY INCONCLUSIVE / REFERENCES PARTIAL / NOT HUMAN PEER REVIEWED / All rights reserved.

## Scope and dependencies

This is a computer-assisted proof proposal extending `symmetric_D2_radius_proof.md` and `symmetric_seven_2adic_proof.md`. The frozen v0.7 necessary residue reduction is assumed; its converse is not needed. Normalize rational radii to distinct positive primitive integers a,b,c. Neither the frozen bundle nor previous certificates are modified. No independent audit or Windows validation.

## Theorem

For p=3 or p=5 the original D=2 matrix for nodes {0,±a,±b,±c} is nonsingular if at least one radius is divisible by p, or if the three p-adic valuations of squared-radius differences are not all equal.

Thus, using also the earlier 2-adic result, any singular rational configuration of this type must have all three primitive radii coprime to 30, squared difference depths d,d,d+1 at 2 (d>=3), and all three squared-difference depths equal at 3 and at 5. At 3, the common depth is >=1 because all nonzero squares are 1 modulo 3. At 5 the common depth is also >=1: three unit squares occupy at most two residue classes. These are necessary conditions, not a full nonsingularity theorem.

## Polynomial proof

Let X,Y,Z denote squared radii. Define g0=(-XYZ)^(-3), gi=(8 Xi^3 product_{j!=i}(Xi-Xj)^3)^(-1), G=g0+2 sum gi, C=-sum gi(9+12 Xi sum_{j!=i}1/(Xi-Xj)). The earlier radius identity gives det M=-(G+C)(3G+2C)/8. Take the primitive integer numerators P1,P2 of these two scalars, with signs fixed by the coefficients -5,-3 of A^4 in Pi(1,A,0). Both are symmetric homogeneous polynomials of degree 12 with 61 terms; denominators are nonzero on admissible radii. By homogeneity and symmetry normalize a unit squared radius to 1. All other coordinates remain p-adic squares. The companion certificate verifies strict weighted monomial comparisons on unbounded cones: if W(i,j)=ie+jf+v_p(c_ij), strict inequality at a base and nonnegative slope along each cone generator imply the inequality throughout the cone. The polynomial identities and comparisons below are reconstructed from the rational scalar expressions, not from a hard-coded list of coefficients.

### Two divisible radii

Use (1,A,B), e=v_p(A), f=v_p(B), both even and >=2. If unequal, arrange f>=e+2. The unique least-weight term is A^4 with coefficient -5 or -3 respectively (including its coefficient valuation). The certificate checks base (2,4) and rays (1,1),(0,1).

If e=f, divide A,B by p^e to get square units u,v. The homogeneous degree-four parts are

H1=-(A^2-3AB+B^2)(5A^2-2AB+5B^2),
H2=-(A^2-3AB+B^2)(3A^2-2AB+3B^2).

Every other term has degree >=5, hence valuation >=5e. For p=3 the unit squares both reduce to 1 and both H_i(u,v) are units. For p=5 and u=v mod 5 both are units. For p=5 and u!=v mod 5 the residues are 1,4 in some order. The second factor of each H_i is a unit and the first factor has valuation exactly one by

4(u^2-3uv+v^2)=(2u-3v)^2-5v^2,

since 2u-3v is divisible by 5. Thus the initial valuation is 4e or 4e+1, strictly less than 5e. Neither scalar numerator vanishes.

### One divisible radius

If the two unit squares agree modulo p, use (1,1+A,B), e=v_p(A)>=1, f=v_p(B)>=2 even. The only possible lowest terms are -5 A^4 and -8 B^3 for P1, or -3 A^4 and -4 B^3 for P2. The certificate compares each other term against at least one of these two on the cone e>=1,f>=2. If the coefficient of A^4 has valuation 1, equality of weights is impossible: 4e+1 is odd and 3f even. Otherwise, in case of a tie, the unit part after scaling equals -5u^4-8v^6 or -3u^4-4v^6, where u is an arbitrary unit and v is a unit square root of the unit part of B. Direct enumeration of the nonzero residues for p=3,5 in the cases with unit A^4 coefficient proves nonvanishing. If the two unit squares differ modulo p, necessarily p=5. Use (1,4+A,B). The constant coefficients -103680 and -62208 have valuations 1 and 0; the certificate verifies they are uniquely lowest for e>=1,f>=2.

### No divisible radii

For p=5 if two square classes occur, exactly one pair collides; the earlier mirror collision theorem applies (p>3). Otherwise all squares occupy one residue class (always the case at p=3). If pairwise difference depths are unequal, the ultrametric property gives d,d,e with e>d>=1. Choose the closest pair as (1,1+A), and the remaining square as 1+B, with v_p(A)=e and v_p(B)=d. The unique least-weight term in Pi(1,1+A,1+B) is B^5, with coefficient 8 or 4. The certificate verifies base (2,1) and rays (1,1),(1,0). Both coefficients are units for p=3,5. This completes the proof given the earlier necessary residue reduction.

## Verification and limitations

Run `symmetric_seven_small_prime_certificate.py` in the directory containing `symmetric_D2_radius_certificate.py`, `d2_moment_reduction.py` and the frozen v0.7 ZIP. Requires Python/SymPy. Both scalar polynomials passed all unbounded weighted cone and residue checks. For primitive positive triples with maximum radius <=50: 16648 total, p=3 covers 15236, p=5 covers 15526, their union covers 16546; all 16546 checked against exact rational scalar evaluations. The previous 2-adic and odd-prime witness conditions (primes 5<=p<101) cover 16643; all conditions together cover 16648. Previous five uncovered triples all covered by the new conditions. The original determinant was not re-evaluated for this full sample, nor was the previous weighted certificate rerun: old witness coverage is recalculated using its predicate. Frozen SHA256 verified. No novel claim about the unresolved primitive triples in general, nor about nonsymmetric nodes. No new literature search or independent audit.
