# Global factorization obstruction for symmetric seven-node rational configurations (D=2)

PRIVATE / HOLD — NOVELTY INCONCLUSIVE / REFERENCES PARTIAL / NOT HUMAN PEER REVIEWED / All rights reserved.

## Scope and dependencies

Use the frozen v0.7 necessary residue reduction and the symmetric D=2 scalar formulas in `symmetric_D2_radius_proof.md`. Use the prior 2-adic and p=3,5 theorems in `symmetric_seven_2adic_proof.md` and `symmetric_seven_small_prime_proof.md`. Both corresponding certificates were replayed successfully this turn. The reduction's converse is not required. The frozen v0.7 ZIP is unmodified, SHA256 ef40748e44e13280e00b4db496a3296119fa1adb2659afb869e5865f3765c6f4. No independent audit or Windows test.

## Theorem 1 (global necessary factorization)

Let 0<a<b<c be primitive positive integer radii, obtained by clearing rational denominators and removing their common gcd. Suppose the original D=2 matrix at {0,±a,±b,±c} is singular. Set d_a=gcd(b,c), d_b=gcd(a,c), d_c=gcd(a,b). Then there are positive integers u_a,u_b,u_c such that

    a=d_b d_c u_a^2, b=d_a d_c u_b^2, c=d_a d_b u_c^2.

Let g=gcd(c^2-b^2,c^2-a^2,b^2-a^2). There are epsilon_a,epsilon_b,epsilon_c in {1,2}, exactly one equal to 2, such that

    c^2-b^2 = g epsilon_a d_a^2 u_a^3,
    c^2-a^2 = g epsilon_b d_b^2 u_b^3,
    b^2-a^2 = g epsilon_c d_c^2 u_c^3.

Furthermore gcd(g,abc)=1, and all radii are coprime to 30. These identities are necessary, not sufficient, for singularity.

### Proof

Let P_1,P_2 be the signed primitive numerators of G+C, 3G+2C from the preceding certificates. They are symmetric homogeneous integer polynomials in the squared radii. Singular A implies singular M, hence at least one P is zero. Fix such a P. Set (K,J)=(5,8) or (3,4), respectively. Direct symbolic reconstruction in the companion certificate proves the following identities/support facts:

1. P(1,Y,0)=-K Y^4(Y-1)^4; P(1,1,Z)=J Z^3(Z-1)^5.
2. P(1,1+A,B) has precisely the componentwise-minimal monomials -K A^4 and -J B^3. Every other monomial is strictly heavier than one of them for positive valuations of A,B at p>=7.
3. P(1,A,B) has no total degree below four, and its degree-four part is -(A^2-3AB+B^2)(K A^2-2AB+K B^2). At A=B=1 this part equals J. For unequal positive valuations of A,B, its least-weight term is the pure fourth power of the less-divisible variable, strictly below every other term, for p>=7.
4. In P(1,1+A,1+B), for e=v_p(A)>=f+1 where f=v_p(B)>=1, the term J B^5 is uniquely least-weight at all odd p for which J is a unit. Indeed every other exponent (i,j) satisfies i+j>=5 and 2i+j>5; hence ie+jf>5f.

These follow from the finite list of monomial exponents, with identities verified exactly in `symmetric_seven_global_certificate.py`. In each p-adic chart divide squared radii by a unit squared radius, using symmetry and homogeneity; none of the valuation comparisons changes when multiplying by such units. The normalized coordinates are p-adic integers.

At p=2 the preceding theorem forces odd radii and sorted difference depths d,d,d+1. At p=3,5 the preceding theorems force unit radii and equal difference depths. Thus these primes never divide a radius.

For any p>=7:

* If p divides no radius, the three difference depths must be equal. If just two squares collide modulo p, identity 1 on P(1,1,Z) excludes zero. If all three collide with unequal depths, choose the closest pair as (1,1+A) and the third square as 1+B; fact 4 excludes zero. If no pair collides all depths are zero.
* If p divides exactly one radius, say a, singularity forces b^2=c^2 mod p by identity 1 applied to P(1,Y,0). Choose b^2 as the unit normalizer. In P(1,1+A,B), v_p(A)=v_p(c^2-b^2)=e>0 and v_p(B)=2v_p(a)=f>0. Because p>=7 all leading coefficients are units. Fact 2 forces 4e=3f; otherwise there is a unique least-weight term. Consequently v_p(a) is even, say 2t, and v_p(c^2-b^2)=3t. The two differences involving a are units.
* If p divides exactly two radii, say b,c, primitivity makes a a unit. By fact 3, unequal squared valuations make P nonzero, so v_p(b)=v_p(c)=t>0. After unit normalization write A=p^{2t}U, B=p^{2t}V. If U=V modulo p the degree-four part equals J U^4 modulo p, which is nonzero; all terms of higher degree have strictly larger valuation. Consequently the two scaled squares differ modulo p, and v_p(c^2-b^2)=2t. The other differences are units.

No prime divides all three radii. The three gcds d_a,d_b,d_c are pairwise coprime; a shared prime has equal exponents in its two radii. All remaining prime powers of each radius have even exponents. This proves the displayed decomposition of the radii. By the primewise analysis, primes dividing abc never divide g. For odd primes not dividing abc the difference valuations are equal and exactly absorbed by g. At 2 exactly one difference has one extra factor 2. For a prime dividing a alone, its residual power in c^2-b^2 is the corresponding power of u_a^3; for a prime dividing b,c it is the corresponding power of d_a^2. All other differences are units in both cases. Permute the labels as needed. Unique factorization proves the three identities. QED.

## Theorem 2 (pairwise coprime radii)

If gcd(a,b)=gcd(a,c)=gcd(b,c)=1 after primitive integer normalization, the original D=2 matrix is nonsingular.

Proof. If singular, Theorem 1 gives a=u^2,b=v^2,c=w^2 with positive u<v<w. The additive identity among differences gives

    epsilon_b v^3 = epsilon_a u^3 + epsilon_c w^3.

Since w>v, epsilon_b must be 2; the other epsilons are 1. Thus v^3 is the midpoint of u^3 and w^3. The function t -> t^(4/3) is strictly convex for t>0, so w^4-v^4>v^4-u^4. On the other hand the original difference equations imply w^4-v^4=g u^3<g w^3=v^4-u^4. Contradiction. QED.

## Corollary (only the two smallest radii share prime factors)

Suppose gcd(a,c)=gcd(b,c)=1 but d_c=gcd(a,b)>1. The original matrix is also nonsingular. Otherwise a=d_c u^2,b=d_c v^2,c=w^2, hence u<v and w>sqrt(d_c)v. The necessary additive equation would give epsilon_b v^3=epsilon_a u^3+epsilon_c d_c^2 w^3. Its right side exceeds d_c^(7/2)v^3>2v^3, impossible. QED.

## Computations and limits

New companion certificate reconstructs both numerator polynomials, checks all local support identities, checks both exact rational scalars for 6106 pairwise coprime triples among 16648 primitive triples up to height 50, and screens all 24754 primitive triples with radii coprime to 30 up to height 200 against Theorem 1. No triple survives the necessary identities. Combined with the prior small-prime theorems this supplies a finite theorem for all primitive triples up to height 200, conditional on the stated proof dependencies; no new direct determinant checks were made for the entire sample. The earlier 2-adic and small-prime certificates were rerun, including their original residual five direct determinant checks. No conclusion for all triples sharing primes in the other patterns. Not a proof of unrestricted rational regularity. No new literature search, full old suite replay, independent audit, or Windows validation.
