# Elimination of single shared-gcd patterns in the symmetric seven-node D=2 problem
2026-11-20 JST — PRIVATE / HOLD
NOVELTY INCONCLUSIVE / REFERENCES PARTIAL / NOT HUMAN PEER REVIEWED / All rights reserved.

## Dependencies and status
Uses Theorem 1 of `symmetric_seven_global_proof.md` in the 2026-11-20 handoff. The 52 manifest entries and the frozen v0.7 archive SHA256 ef40748e44e13280e00b4db496a3296119fa1adb2659afb869e5865f3765c6f4 matched. The global, 2-adic, and small-prime certificates were replayed successfully in this session. No full v0.7 suite replay, independent audit or Windows run. No change to the frozen archive. These proposed proofs depend on the necessary residue reduction and radius formulas, not their converse.

Write d=d_a=gcd(b,c), e=d_b=gcd(a,c), f=d_c=gcd(a,b), and u=u_a,v=u_b,w=u_c. Assume singularity, so
    a=ef u^2, b=df v^2, c=de w^2,
    c^2-b^2=g eps_a d^2 u^3,
    c^2-a^2=g eps_b e^2 v^3,
    b^2-a^2=g eps_c f^2 w^3.
Exactly one epsilon is 2; all others 1. All radii are coprime to 30, hence each nontrivial gcd is >=7. Also a<b<c. Divide the additive relation by the positive common factor (def)^(-3/2) to obtain
    eps_b e^(7/2)b^(3/2)=eps_a d^(7/2)a^(3/2)+eps_c f^(7/2)c^(3/2).

## Proposition 1: if e=1, then f=1 is necessary for singularity
From the last equality, 2 b^(3/2)> f^(7/2)c^(3/2), so f^(7/2)<2. As f is a positive integer coprime to 30, f=1. This also excludes d>1,f>1,e=1, extending the earlier smallest-pair-only result.

## Proposition 2: d=f=1, e>1 is impossible
Then a=e u^2,b=v^2,c=e w^2, so u<w. The difference equations give c^2-b^2 <= 2(b^2-a^2), hence c^2<3b^2. But eps_b e^2 v^3=eps_a u^3+eps_c w^3<4w^3. Thus (b/c)^3=v^6/(e^3 w^6)<16/e^7<=16/7^7<1/27, so b/c<1/3, contradicting c^2<3b^2.

## Proposition 3: d>1, e=f=1 is impossible
Here a=u^2,b=d v^2,c=d w^2, with w>v. The additive equality forces eps_b=2, eps_a=eps_c=1. Then d^2 u^3=2v^3-w^3<v^3. Put X=(a/b)^2, t=w/v, Z=(c/b)^2=t^4. In particular 0<X<d^(-14/3)<1/2401. Dividing the first difference by the third produces
    (t^4-1)/(1-X)=(2-t^3)/t^3,
    t^7=2-X(2-t^3).
As 1<t^3<2, 2-X<t^7<2. Since (11/10)^7<2-1/2401 and (11/10)^4>7/5, we obtain 7/5<Z<2.

The two scalar numerator polynomials P1,P2 in squared radii are homogeneous, so a singular point would satisfy P_i(X,1,Z)=0 for at least one i. Reconstruct from the radius formulas. For each i the signed numerator is p0(Z)+X p1(Z)+X^2 p2(Z)+R(X,Z), where
    p0=-K Z^4(Z-1)^4;
    p1=L Z^3(Z-1)^4(Z+1);
    p2=-Z^2(Z-1)^4(H Z^2+I Z+H).
(K,L,H,I)=(5,17,16,53) or (3,11,12,37). All remaining powers of X are at least 3. On the rectangle 0<X<=1/2401, 7/5<=Z<=2, p1/|p0|<8 and p2<=0. Direct exact expansion yields a bound |R|<=M X^3, with M=sum_{i>=3,j}|c_ij|2^j=64184 or 44392. In particular
    P <= -K(7/5)^4(2/5)^4(1-8/2401)+M/2401^3 < 0.
Both final rational inequalities and the coefficient identities are checked by the new companion certificate. Thus neither numerator can vanish, contradiction. No finite radius bound is used in the proof.

## Proposition 4: an additional two-shared-gcd subcase
If d=1, e>1, f>1 and eps_a=2, no singularity is possible. Here v^2>e u^2 because a<b. Define S=(c^2-b^2)/(c^2-a^2)=2u^3/(e^2v^3). Then 0<S<2/e^(7/2). Also b^2/c^2=1-S(1-a^2/c^2)>1-S. The additive equality with eps_b=eps_c=1 gives f^2w^3=e^2v^3(1-S). Consequently
    (f/e)^7=(b/c)^3(1-S)^2>(1-S)^(7/2)>=1-(7/2)S>1-1/e.
The middle inequality is Bernoulli's inequality and the last uses e>=7. But (f/e)^7<1, so f<e and (f/e)^7<=(1-1/e)^7<=1-1/e, contradiction.

## Remaining cases
The earlier pairwise-coprime proof and Propositions 1–3 exclude all patterns with at most one nontrivial shared gcd, and the pattern d>1,f>1,e=1. Proposition 4 excludes part of d=1,e>1,f>1. Any singular triple must have e>1 and at least one of d,f>1. The remaining cases are d=1,e>1,f>1 with eps_a=1; d>1,e>1,f=1; and d,e,f>1. The complete rational seven-node theorem remains open in this work, as do the unrestricted rational problem and the novelty assessment. The new certificate checks exact polynomial identities and inequalities, not an independent audit. No claim of first discovery.
