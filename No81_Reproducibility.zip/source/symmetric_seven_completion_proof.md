# Seven-node rational regularity via a seventh-power arithmetic progression
2026-11-20 JST — Research continuation, PRIVATE / HOLD.
NOVELTY INCONCLUSIVE / REFERENCES PARTIAL / NOT HUMAN PEER REVIEWED / All rights reserved.

## Statement and dependencies
The original D=2 logarithmic coefficient matrix A, with entries A[n,(i,j)] = b_i^(n-j)/(n-j) for n>j and zero otherwise (n=1,...,18; i=1,...,6; j=0,1,2), is nonsingular for the seven distinct nodes {0, ±a, ±b, ±c}, where a,b,c are positive distinct rationals. This is a proof proposal pending independent audit. Scaling by a nonzero rational lambda multiplies row n by lambda^n and column (i,j) by lambda^(-j), so denominators may be cleared and the gcd removed. Order 0<a<b<c and gcd(a,b,c)=1.

Dependencies: frozen v0.7 (SHA256 ef40748e44e13280e00b4db496a3296119fa1adb2659afb869e5865f3765c6f4), in particular its nested v0.5 necessary residue reduction; symmetric_D2_radius_proof.md; symmetric_seven_2adic_proof.md; symmetric_seven_small_prime_proof.md; Theorem 1 in symmetric_seven_global_proof.md. No reverse residue reduction is used. The preceding single-gcd case analysis is not needed. The cited theorem of Darmon and Merel is an external established theorem, not newly proved here.

## Proof
Suppose A singular. By the global factorization theorem, define d=gcd(b,c), e=gcd(a,c), f=gcd(a,b). Then there exist positive integers u,v,w,g and eps_a,eps_b,eps_c in {1,2}, exactly one 2, with

    a=e f u^2, b=d f v^2, c=d e w^2,
    c^2-b^2=g eps_a d^2 u^3,
    c^2-a^2=g eps_b e^2 v^3,
    b^2-a^2=g eps_c f^2 w^3.

The three square factors u,v,w have common gcd 1: any common prime would divide a,b,c. After dividing each difference by its shared factor squared,

    e^2 w^4-f^2 v^4=g eps_a u^3,
    d^2 w^4-f^2 u^4=g eps_b v^3,
    d^2 v^4-e^2 u^4=g eps_c w^3.

Multiply the first by u^4, the second by v^4, the third by w^4. The sum of the first and third left sides equals the second. Cancel positive g to obtain

    eps_a u^7 + eps_c w^7 = eps_b v^7.

Darmon–Merel, Main Theorem (1), states that X^n+Y^n=2 Z^n has no nontrivial primitive integer solution for n>=3, where trivial means XYZ=0 or ±1. The author-hosted manuscript dated 2001-01-05, pp. 1–2, was consulted directly (including page images); the journal article is J. reine angew. Math. 490 (1997), 81–100, DOI: 10.1515/crll.1997.490.81. URL: https://perso.imj-prg.fr/loic-merel/wp-content/uploads/merel-pub/winding.pdf .

If eps_a=2 then (X,Y,Z)=(v,-w,u); if eps_c=2 then (v,-u,w); if eps_b=2 then (u,w,v). Each triple is primitive and has nonzero product. The theorem forces u=v=w=1, because they are positive integers. The first two sign-mixed cases are then incompatible with the original seventh-power equality. Hence eps_b=2, eps_a=eps_c=1.

The divided square-difference equations now reduce to e^2-f^2=g and d^2-e^2=g. Put t=f^2>0 and h=g>0. Then the squared radii (X,Y,Z)=(a^2,b^2,c^2) are

    X=t(t+h), Y=t(t+2h), Z=(t+h)(t+2h).

No assumption about which shared factors are nontrivial is needed. In particular this remaining branch must be checked, rather than being dismissed as a trivial configuration: distinct radii are still possible before imposing the scalar equations.

For squared radii X_i in {X,Y,Z}, put

    g0=1/(-XYZ)^3,
    gi=1/[8 X_i^3 product_{j!=i}(X_i-X_j)^3],
    G=g0+2 sum_i gi,
    C=-sum_i gi (9+12 X_i sum_{j!=i}1/(X_i-X_j)).

The centered D=2 residue matrix M has det M=-(G+C)(3G+2C)/8. Set H=h^6 t^6(t+h)^6(t+2h)^6. Exact rational simplification yields

    G+C=3 F/(32 H),
    3G+2C=3 J/(4 H),

where

    F=84h^6+600h^5t+1396h^4t^2+1680h^3t^3+1150h^2t^4+438ht^5+73t^6,
    J=(11h^2+12ht+6t^2)(2h^4+12h^3t+18h^2t^2+12ht^3+3t^4).

All factors and coefficients are positive at t,h>0. Both rational identities are obtained by direct substitution into the scalar expressions and checked symbolically by symmetric_seven_completion_certificate.py. Thus det M<0 on this branch, contradicting singularity of A, which requires singularity of M. QED subject to the stated proof dependencies.

## Status and limits
This closes all shared-gcd patterns simultaneously, including the arithmetic-progression exceptional branch. It is an unbounded theorem proposal for the centrally symmetric seven-node D=2 family only. It does not settle arbitrary nonsymmetric seven-node configurations, nine-node symmetric configurations, arbitrary D or the original unrestricted rational conjecture. The new proof uses exact symbolic identities, no finite height cutoff, and depends on the external generalized Fermat theorem. It is not an independent audit. The frozen mathematical source is unchanged; no v0.8 freeze or Windows test; no publication permission. Novelty remains inconclusive. The primewise support proof and necessary residue reduction require review as part of the future independent audit.
