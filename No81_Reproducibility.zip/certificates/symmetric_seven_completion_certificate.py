"""Research-only exact algebra certificate. External Darmon–Merel theorem is cited, not machine-proved."""
from pathlib import Path
import hashlib
import sympy as s
from math import prod

d,e,f,u,v,w,g,A,B,C=s.symbols('d e f u v w g A B C', positive=True)
a,b,c=e*f*u**2,d*f*v**2,d*e*w**2
E1=s.expand((c*c-b*b)/d**2-g*A*u**3)
E2=s.expand((c*c-a*a)/e**2-g*B*v**3)
E3=s.expand((b*b-a*a)/f**2-g*C*w**3)
assert s.expand(u**4*E1-v**4*E2+w**4*E3+g*(A*u**7-B*v**7+C*w**7))==0
print('PASS elimination identity: all shared gcds cancel')
# On the only possible Darmon–Merel branch, u=v=w=1 and B=2.
assert s.expand(E1.subs({u:1,v:1,w:1,A:1})-(e**2-f**2-g))==0
assert s.expand(E3.subs({u:1,v:1,w:1,C:1})-(d**2-e**2-g))==0
print('PASS residual reciprocal-square arithmetic progression')
t,h=s.symbols('t h',positive=True)
X,Y,Z=t*(t+h),t*(t+2*h),(t+h)*(t+2*h)
xs=(X,Y,Z); G=1/prod(-x for x in xs)**3; Co=0
for i,x in enumerate(xs):
    ds=[x-y for j,y in enumerate(xs) if j!=i]
    gi=1/(8*x**3*prod(ds)**3)
    G+=2*gi
    Co-=gi*(9+12*x*sum(1/delta for delta in ds))
H=h**6*t**6*(t+h)**6*(t+2*h)**6
F=84*h**6+600*h**5*t+1396*h**4*t**2+1680*h**3*t**3+1150*h**2*t**4+438*h*t**5+73*t**6
J=(11*h**2+12*h*t+6*t**2)*(2*h**4+12*h**3*t+18*h**2*t**2+12*h*t**3+3*t**4)
assert s.cancel((G+Co)*32*H-3*F)==0
assert s.cancel((3*G+2*Co)*4*H-3*J)==0
assert all(c>0 for p in (F,J) for c in s.Poly(p,t,h).coeffs())
print('PASS both scalar rational identities and positive coefficients for all t,h>0')
print('FINAL: PASS EXACT ALGEBRA; prior local theorems and external theorem remain proof dependencies')
