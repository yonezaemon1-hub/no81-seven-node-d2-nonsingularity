"""PRIVATE/HOLD. Symbolic and exact-inequality checks for the new proof note."""
from fractions import Fraction as Q
from math import prod
import sympy as s
x,y,z=s.symbols('x y z'); Y=(x,y,z)
G=1/prod(-v for v in Y)**3; C=0
for i,v in enumerate(Y):
    ds=[v-w for j,w in enumerate(Y) if i!=j]
    h=1/(8*v**3*prod(ds)**3)
    G+=2*h; C-=h*(9+12*v*sum(1/d for d in ds))
for k,f in enumerate((G+C,3*G+2*C)):
    K,L,H,I=(5,17,16,53) if k==0 else (3,11,12,37)
    P=s.Poly(s.cancel(f).as_numer_denom()[0],*Y).primitive()[1].as_expr().subs(y,1)
    if P.coeff(x,0).coeff(z,4)>0: P=-P
    p0=-K*z**4*(z-1)**4
    p1=L*z**3*(z-1)**4*(z+1)
    p2=-z**2*(z-1)**4*(H*z*z+I*z+H)
    for i,a in enumerate((p0,p1,p2)): assert s.expand(P.coeff(x,i)-a)==0
    tail=sum(abs(c)*2**j for (i,j),c in s.Poly(P,x,z).terms() if i>=3)
    assert tail <= 65000
    # On 0<X<=1/2401, 7/5<=Z<=2: p1/(-p0)<8; p2<=0.
    lower=K*Q(7,5)**4*Q(2,5)**4
    assert Q(L,K)*2<8
    assert lower*(1-Q(8,2401)) > Q(int(tail),2401**3)
    print('PASS scalar',k+1,'uniform negative rectangle; tail',tail)
assert Q(11,10)**7 < 2-Q(1,2401)
assert Q(11,10)**4 > Q(7,5)
assert 2**4 < 2**7 # t^7<2 implies t^4<2 for t>1
assert Q(16,7**7)<Q(1,27)
# For d_a=1,d_b=e>=7,d_c=f, eps_a=2: 7/e^(7/2)<1/e.
assert 7**2 < 7**5
print('PASS exact threshold inequalities')
