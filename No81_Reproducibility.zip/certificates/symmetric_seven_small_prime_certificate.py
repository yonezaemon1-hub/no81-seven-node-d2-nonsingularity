"""PRIVATE/HOLD. D=2 symmetric seven-node sufficient conditions at p=3,5."""
from itertools import combinations
from math import prod,gcd
from pathlib import Path
from collections import Counter
import hashlib
import sympy as s
from symmetric_D2_radius_certificate import scalars,vp,witness
x,y,z,A,B=s.symbols('x y z A B'); Y=(x,y,z)
G=1/prod(-v for v in Y)**3; C=0
for i,v in enumerate(Y):
    ds=[v-w for j,w in enumerate(Y) if i!=j]
    g=1/(8*v**3*prod(ds)**3); G+=2*g; C-=g*(9+12*v*sum(1/d for d in ds))
Ps=[]
for f in (G+C,3*G+2*C):
    P=s.Poly(s.cancel(f).as_numer_denom()[0],*Y).primitive()[1]
    if P.as_expr().subs({x:1,z:0}).coeff(y,4)>0:P=-P
    assert P.total_degree()==12 and len(P.terms())==61
    for u,v in [(x,y),(y,z)]: assert s.expand(P.as_expr()-P.as_expr().subs({u:v,v:u},simultaneous=True))==0
    Ps.append(P.as_expr())
def terms(P,sub):return dict(s.Poly(P.subs(dict(zip(Y,sub)),simultaneous=True),A,B).terms())
def weight(ij,c,p,e,f):return ij[0]*e+ij[1]*f+vp(int(c),p)
def strict(T,lead,p,base,dirs):
    for ij,c in T.items():
        if ij==lead:continue
        i,j=ij[0]-lead[0],ij[1]-lead[1]
        assert weight(ij,c,p,*base)>weight(lead,T[lead],p,*base),(p,ij,lead,base)
        assert all(i*e+j*f>=0 for e,f in dirs)
for idx,P in enumerate(Ps):
    for p in [3,5]:
        # Two divisible radii, distinct squared valuations; e>=2, f>=e+2.
        T=terms(P,(1,A,B)); assert T[4,0]==(-5,-3)[idx]
        strict(T,(4,0),p,(2,4),[(1,1),(0,1)])
        # Same valuation e>=2. All terms of degree >=5 have valuation >=5e.
        assert min(map(sum,T))==4
        H=sum(c*A**i*B**j for (i,j),c in T.items() if i+j==4)
        expected=-(A*A-3*A*B+B*B)*((5*A*A-2*A*B+5*B*B) if idx==0 else (3*A*A-2*A*B+3*B*B))
        assert s.expand(H-expected)==0
        for u in set(i*i%p for i in range(1,p)):
            for v in set(i*i%p for i in range(1,p)):
                if p==5 and u!=v:
                    # first factor has exact valuation 1 via (2u-3v)^2-5v^2; other factor unit
                    assert (2*u-3*v)%5==0
                    assert (int((expected/(-(A*A-3*A*B+B*B))).cancel().subs({A:u,B:v})))%5!=0
                else:assert int(H.subs({A:u,B:v}))%p!=0
        # One divisible radius, remaining squares equal mod p.
        T=terms(P,(1,1+A,B)); cand=[(4,0),(0,3)]
        assert T[4,0]==(-5,-3)[idx] and T[0,3]==(-8,-4)[idx]
        for (i,j),c in T.items():
            if (i,j) in cand:continue
            assert any(i>=I and j>=J and weight((i,j),c,p,1,2)>weight((I,J),T[I,J],p,1,2) for I,J in cand)
        w=vp(int(T[4,0]),p)
        # if w=1, no tie by parity. Otherwise check possible leading unit sums.
        if w==0:
            for u in range(1,p):
                for v in range(1,p):assert (int(T[4,0])*u**4+int(T[0,3])*v**6)%p!=0
        else:assert w==1 and vp(int(T[0,3]),p)==0
        # All unit radii, same squared residue, unequal difference depths.
        T=terms(P,(1,1+A,1+B)); assert T[0,5]==(8,4)[idx]
        strict(T,(0,5),p,(2,1),[(1,1),(1,0)])
        if p==5:
            # Exactly one divisible radius, other two distinct square residues.
            T=terms(P,(1,4+A,B)); assert vp(int(T[0,0]),p)==(1,0)[idx]
            strict(T,(0,0),p,(1,2),[(1,0),(0,1)])
    print('PASS all unbounded weighted cones and unit cases for scalar',idx+1,flush=True)

def new(a,p):
    if any(v%p==0 for v in a):return True
    ds=[vp(u*u-v*v,p) for u,v in combinations(a,2)]
    # p=5 with two distinct square classes: exactly one pair collision, old theorem.
    return max(ds)>min(ds)
def old2(a):
    if any(v%2==0 for v in a):return True
    ds=sorted(vp(u*u-v*v,2) for u,v in combinations(a,2))
    return ds[2]>=ds[0]+2
counts=Counter(); missed=[];oldmiss=[]
for a in combinations(range(1,51),3):
    if gcd(*a)!=1:continue
    old=old2(a) or any(witness(a,p) for p in s.primerange(5,101))
    b,c=new(a,3),new(a,5)
    counts.update({'total':1,'p3':b,'p5':c,'p3_or_p5':b or c,'old':old,'union':old or b or c})
    if b or c:assert all(scalars(a)),a
    if not old:oldmiss.append((a,b,c))
    if not(old or b or c):missed.append(a)
print('PASS exact rational scalar checks',counts['p3_or_p5'],flush=True)
print('coverage',dict(counts),'old misses',oldmiss,'new misses',missed,flush=True)
f=next(Path(__file__).parent.glob('finite_logarithmic_multidegree_v07_PRIVATE_HOLD*.zip'))
assert hashlib.sha256(f.read_bytes()).hexdigest()=='ef40748e44e13280e00b4db496a3296119fa1adb2659afb869e5865f3765c6f4'
print('PASS frozen v0.7 SHA256',flush=True)
