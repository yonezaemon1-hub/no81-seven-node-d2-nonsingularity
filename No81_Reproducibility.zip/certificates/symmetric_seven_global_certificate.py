"""PRIVATE/HOLD: global necessary factorization for D=2 symmetric 7 nodes.
Symbolic ingredients are rebuilt from the exact radius formulas. The proof
also uses the previously certified 2,3,5-adic conditions.
"""
from itertools import combinations
from math import gcd, prod
from pathlib import Path
import hashlib
import tempfile, zipfile, sys
import sympy as s
from symmetric_D2_radius_certificate import scalars

x,y,z,A,B=s.symbols('x y z A B'); Y=(x,y,z)
G=1/prod(-v for v in Y)**3; C=0
for i,v in enumerate(Y):
    ds=[v-w for j,w in enumerate(Y) if i!=j]
    g=1/(8*v**3*prod(ds)**3)
    G+=2*g; C-=g*(9+12*v*sum(1/d for d in ds))
for idx,f in enumerate((G+C,3*G+2*C)):
    P=s.Poly(s.cancel(f).as_numer_denom()[0],*Y).primitive()[1]
    if P.as_expr().subs({x:1,z:0}).coeff(y,4)>0:P=-P
    P=P.as_expr(); K=(5,3)[idx]; J=(8,4)[idx]
    assert s.Poly(P,*Y).is_homogeneous
    for u,v in [(x,y),(y,z)]:
        assert s.expand(P-P.subs({u:v,v:u},simultaneous=True))==0
    assert s.expand(P.subs({x:1,z:0})+K*y**4*(y-1)**4)==0
    assert s.expand(P.subs({x:1,y:1})-J*z**3*(z-1)**5)==0
    def terms(sub):return dict(s.Poly(P.subs(dict(zip(Y,sub)),simultaneous=True),A,B).terms())
    T=terms((1,1+A,1+B)); assert T[0,5]==J
    # e>=f+1, f>=1: all other terms weigh strictly more than B^5.
    # e=f+1+u, f=1+v with u,v nonnegative.
    for i,j in T:
        if (i,j)==(0,5):continue
        assert 2*i+j>5 and i+j>=5
    T=terms((1,1+A,B)); assert T[4,0]==-K and T[0,3]==-J
    assert all((i>=4 or j>=3) for i,j in T)
    # All other monomials strictly heavier than one of the two minima.
    T=terms((1,A,B)); assert min(map(sum,T))==4 and T[4,0]==T[0,4]==-K
    H=sum(c*A**i*B**j for (i,j),c in T.items() if i+j==4)
    expected=-(A*A-3*A*B+B*B)*(K*A*A-2*A*B+K*B*B)
    assert s.expand(H-expected)==0
    assert H.subs({A:1,B:1})==J
    print('PASS scalar',idx+1,'all-prime local support identities',flush=True)

# Numerical checks are supplementary, not the proof of the unbounded theorem.
count=pairwise=0
for t in combinations(range(1,51),3):
    if gcd(*t)!=1:continue
    count+=1
    if all(gcd(i,j)==1 for i,j in combinations(t,2)):
        assert all(scalars(t));pairwise+=1
print('PASS exact rational scalars for pairwise coprime triples',pairwise,'of',count,'primitive triples',flush=True)
# Check necessary global identities as a screening predicate up to height 200.
# All local restrictions are necessary only; surviving triples need further proof.
from math import isqrt
eligible=0; survivors=[]
for a,b,c in combinations([i for i in range(1,201) if gcd(i,30)==1],3):
    if gcd(a,b,c)!=1:continue
    eligible+=1
    da,db,dc=gcd(b,c),gcd(a,c),gcd(a,b)
    t=(a//(db*dc),b//(da*dc),c//(da*db))
    u=tuple(isqrt(i) for i in t)
    if tuple(i*i for i in u)!=t:continue
    d=(c*c-b*b,c*c-a*a,b*b-a*a); g=gcd(*d)
    if gcd(g,a*b*c)!=1:continue
    base=tuple(v**2*w**3 for v,w in zip((da,db,dc),u))
    if any(all(d[i]==g*base[i]*(2 if i==k else 1) for i in range(3)) for k in range(3)):survivors.append((a,b,c))
print('Global necessary identity screen: height <=200, primitive radii coprime to 30:',eligible,'survivors',survivors,flush=True)
f=next(Path(__file__).parent.glob('finite_logarithmic_multidegree_v07_PRIVATE_HOLD*.zip'))
assert hashlib.sha256(f.read_bytes()).hexdigest()=='ef40748e44e13280e00b4db496a3296119fa1adb2659afb869e5865f3765c6f4'
print('PASS frozen v0.7 SHA256',flush=True)
