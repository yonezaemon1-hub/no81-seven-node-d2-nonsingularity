"""PRIVATE/HOLD. D=2 odd centrally symmetric configurations. Python 3 + SymPy."""
from fractions import Fraction as F
from itertools import combinations
from math import prod,gcd
from pathlib import Path
import hashlib, zipfile, tempfile, sys, sympy as s
from d2_moment_reduction import moments

def scalars(a):
    y=[v*v for v in a]; symbolic=isinstance(y[0],s.Basic)
    inv=lambda v: 1/v if symbolic else F(1,v)
    G=inv(prod(-v for v in y)**3); C=0
    for i,v in enumerate(y):
        ds=[v-w for j,w in enumerate(y) if j!=i]
        g=inv(8*v**3*prod(ds)**3)
        G+=2*g; C-=g*(9+12*v*sum(map(inv,ds)))
    return G+C,3*G+2*C

def vp(x,p):
    x=F(x)
    if not x:return float('inf')
    def v(n):
        k=0
        while n%p==0:n//=p;k+=1
        return k
    return v(x.numerator)-v(x.denominator)

def witness(a,p):
    zero=[i for i,x in enumerate(a) if x%p==0]
    pairs=[(i,j) for i,j in combinations(range(len(a)),2) if (a[i]*a[i]-a[j]*a[j])%p==0]
    if p>5 and len(zero)==1 and not pairs:return 'triple',vp(a[zero[0]],p)
    if p>3 and not zero and len(pairs)==1:
        i,j=pairs[0];return 'mirror',vp(a[i]**2-a[j]**2,p)
    return None

def main():
    z=next(Path(__file__).parent.glob('finite_logarithmic_multidegree_v07_PRIVATE_HOLD*.zip'))
    assert hashlib.sha256(z.read_bytes()).hexdigest()=='ef40748e44e13280e00b4db496a3296119fa1adb2659afb869e5865f3765c6f4'
    print('PASS frozen v0.7 SHA256',flush=True)
    x=s.Symbol('x'); count=0
    for b in range(2,21):
        deg=[]
        for f in scalars([s.Integer(1),s.Integer(b),x]):
            num,den=s.cancel(f).as_numer_denom(); pol=s.Poly(num,x,domain=s.QQ)
            roots=s.polys.polytools.ground_roots(pol)
            assert all(t in {0,1,-1,b,-b} for t in roots),(b,roots)
            deg.append(pol.degree());count+=1
        print('PASS fixed radii 1',b,'rational roots excluded; degrees',deg,flush=True)
    print('PASS rational root exclusions',count,flush=True)
    ps=list(s.primerange(5,100));checks=cross=0; difficult=[]
    for m,H in [(3,30),(4,16)]:
        n=covered=tr=mi=0;uncovered=[]
        for a in combinations(range(1,H+1),m):
            if gcd(*a)!=1:continue
            f,g=scalars(a);assert f and g,a
            n+=1; hit=False
            if n<=100:
                G,C,R,T,U=moments([0]+list(a)+[-x for x in a]);assert (f,g)==(G+C,3*G+2*C);assert R==T==U==0;cross+=1
            for p in ps:
                w=witness(a,p)
                if not w:continue
                kind,e=w; v=-6*e if kind=='triple' else -4*e
                assert vp(f,p)==vp(g,p)==v,(a,p,w,f,g)
                checks+=1;hit=True
                if kind=='triple':tr+=1
                else:mi+=1
            covered+=hit
            if not hit:uncovered.append(a);difficult.append(a)
        print('PASS primitive integer radii',m,H,'total',n,'covered',covered,'uncovered',len(uncovered),'triple witnesses',tr,'mirror witnesses',mi,'first uncovered',uncovered[:3],flush=True)
    print('PASS valuation checks',checks,'moment crosschecks',cross,flush=True)
    n=0
    for p in (7,11,13,17):
        for e in range(1,7):
            for a in [(1,2,p**e),(1,1+p**e,2)]:
                kind,d=witness(a,p);assert d==e
                v=-6*e if kind=='triple' else -4*e
                assert all(vp(f,p)==v for f in scalars(a));n+=1
    print('PASS deep constructed witnesses',n,flush=True)
    with tempfile.TemporaryDirectory() as tmp:
        with zipfile.ZipFile(z) as zz:
            for file in ('compressed.py','check_v07.py'):zz.extract(file,tmp)
        sys.path.insert(0,tmp)
        from check_v07 import original
        from compressed import exact_M
        for a in difficult:
            b=[0]+list(a)+[-v for v in a]
            f,g=scalars(a);M=exact_M(3,b)
            assert M[0][0]*M[1][1]-M[0][1]*M[1][0]==-f*g/8
            assert original(3,b)!=0,a
        print('PASS difficult configurations: frozen exact M and original integer determinant',len(difficult),flush=True)
if __name__=='__main__':main()
