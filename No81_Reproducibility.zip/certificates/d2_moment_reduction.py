"""D=2 moment identity; comparison with frozen v0.7. Research only."""
from fractions import Fraction as F
from math import prod
from random import Random
from pathlib import Path
import zipfile, tempfile, sys, hashlib

def moments(nodes):
    G,C,R,T,U= [F(0)]*5
    for a in map(F,nodes):
        v=[1/(a-b) for b in nodes if a!=b]
        g=prod(v)**3; c=-3*sum(v)*g
        G+=g; C+=a*c; R+=c; T+=a*g; U+=a*a*c
    return G,C,R,T,U

def matrix(nodes):
    G,C,R,T,U=moments(nodes)
    return [[-(3*G+2*C)/4,-(5*T+2*U)/4],[R/2,(G+C)/2]]

def det(A):return A[0][0]*A[1][1]-A[0][1]*A[1][0]

def main():
    z=next(Path(__file__).parent.glob('finite_logarithmic_multidegree_v07_PRIVATE_HOLD*.zip'))
    assert hashlib.sha256(z.read_bytes()).hexdigest()=='ef40748e44e13280e00b4db496a3296119fa1adb2659afb869e5865f3765c6f4'
    with tempfile.TemporaryDirectory() as t:
        with zipfile.ZipFile(z) as f:
            for name in ('compressed.py','check_v07.py'): f.extract(name,t)
        sys.path.insert(0,t)
        from compressed import exact_M
        rng=Random(261119); count=0
        for n in range(2,9):
            for _ in range(30):
                b=rng.sample(range(-25,26),n); b=[a-b[0] for a in b]
                assert matrix(b)==exact_M(3,b),b
                count+=1
        print('PASS exact matrix entries',count)
        count=0
        for m in range(1,5):
            for odd in (False,True):
                for _ in range(20):
                    a=rng.sample(range(1,26),m); b=sorted(a+[-x for x in a]+([0] if odd else []))
                    G,C,R,T,U=moments(b)
                    if odd: assert R==T==U==0
                    else: assert G==C==0
                    assert det(matrix(b))==det(exact_M(3,b)),b
                    count+=1
        print('PASS centered symmetric parity and determinant',count)
if __name__=='__main__':main()
