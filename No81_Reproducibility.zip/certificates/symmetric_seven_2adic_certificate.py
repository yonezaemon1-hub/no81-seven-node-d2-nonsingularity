"""PRIVATE/HOLD: exact weighted-monomial certificate, D=2, seven symmetric nodes."""
from pathlib import Path
from math import prod,gcd
from itertools import combinations
from collections import Counter
from fractions import Fraction
import hashlib, tempfile, zipfile, sys
import sympy as s
from symmetric_D2_radius_certificate import scalars,vp,witness

x,y,z,a,b,u=s.symbols('x y z a b u')
Y=(x,y,z)
G=1/prod(-v for v in Y)**3; C=0
for i,v in enumerate(Y):
    ds=[v-w for j,w in enumerate(Y) if i!=j]
    g=1/(8*v**3*prod(ds)**3)
    G+=2*g; C-=g*(9+12*v*sum(1/d for d in ds))
# Fix sign to get P(1,a,0)=-5*a**4*(1-a)**4 or -3*...
Ps=[]
for f in (G+C,3*G+2*C):
    num,den=s.cancel(f).as_numer_denom()
    P=s.Poly(num,*Y).primitive()[1]
    if s.Poly(P.as_expr().subs({x:1,z:0}),y).coeff_monomial(y**4)>0:P=-P
    assert P.total_degree()==12 and len(P.terms())==61
    assert s.expand(P.as_expr()-P.as_expr().subs({x:y,y:x},simultaneous=True))==0
    assert s.expand(P.as_expr()-P.as_expr().subs({y:z,z:y},simultaneous=True))==0
    Ps.append(P.as_expr())

def terms(P,sub):
    return s.Poly(P.subs(dict(zip(Y,sub)),simultaneous=True),a,b).terms()

def check_linear(T,lead,base,dirs):
    # e,f in base + nonnegative linear combination of dirs.
    i0,j0=lead;c0=dict(T)[lead];v0=vp(int(c0),2)
    for (i,j),c in T:
        if (i,j)==lead:continue
        di,dj=i-i0,j-j0; dv=vp(int(c),2)-v0
        assert di*base[0]+dj*base[1]+dv>0,(lead,i,j,base)
        assert all(di*e+dj*f>=0 for e,f in dirs),(lead,i,j,dirs)

for idx,P in enumerate(Ps):
    # One odd, unequal even-radius valuations: A,B squared; v(B)>=v(A)+2.
    check_linear(terms(P,(1,a,b)),(4,0),(2,4),[(1,1),(0,1)])
    # One odd, equal even-radius valuations: B is squared-radius difference.
    check_linear(terms(P,(1,a,a+b)),(4,0),(2,5),[(1,1),(0,1)])
    # All odd, closest pair (1,1+A), v(A)>=v(B)+2, v(B)>=3.
    check_linear(terms(P,(1,1+a,1+b)),(0,5),(5,3),[(1,1),(1,0)])
    # Two odd, one even: compare all remaining terms to either candidate.
    T=terms(P,(1,1+a,b)); td=dict(T); cand=[(4,0),(0,3)]
    assert td[(4,0)]==(-5,-3)[idx] and td[(0,3)]==(-8,-4)[idx]
    for (i,j),c in T:
        if (i,j) in cand:continue
        assert any(i>=I and j>=J and (i-I)*3+(j-J)*2+vp(int(c),2)-vp(int(td[I,J]),2)>0 for I,J in cand),((i,j),c)
    if idx==1:
        # Tie 4e=3f+2, f even; e>=3 gives (e,f)=(5+3t,6+4t).
        for (i,j),c in T:
            if (i,j) in cand:continue
            assert 5*i+6*j+vp(int(c),2)-20>=3
            assert 3*i+4*j-12>=0
    # All odd boundary: construct an actual Q_2 root of each scalar numerator.
    pol=s.Poly(P.subs({x:1,y:1+16*u,z:9}),u)
    v=min(vp(int(c),2) for c in pol.all_coeffs()); assert v==(18,17)[idx]
    H=s.Poly(pol.as_expr()/2**v,u,domain=s.ZZ)
    assert s.Poly(H,u,modulus=2).as_expr()==u+1
    # Hensel lifts from u=1. Distinctness and square classes remain automatic.
    root=1
    for k in range(1,17):
        assert int(H.eval(root))%2**k==0
        if int(H.eval(root))%2**(k+1): root+=2**k
    assert int(H.eval(root))%2**17==0
    print('PASS weighted polynomial',idx+1,'61 terms; simple Q2 root in boundary; u mod 2^17 =',root,flush=True)

def covered(a):
    odds=[v for v in a if v%2]; ev=[v for v in a if v%2==0]
    if ev:return True
    depths=sorted(vp(i*i-j*j,2) for i,j in combinations(odds,2))
    return depths[2]>=depths[0]+2

counts=Counter(); missed=[]; cross=0
for a0 in combinations(range(1,51),3):
    if gcd(*a0)!=1:continue
    hit=covered(a0); old=any(witness(a0,p) for p in s.primerange(5,101));counts['total']+=1;counts['new']+=hit;counts['old']+=old;counts['union']+=(hit or old);counts['extra']+=(hit and not old)
    if not (hit or old):missed.append(a0)
    if hit:
        f,g=scalars(a0);assert f and g;cross+=1
print('PASS exact rational scalar checks',cross,flush=True)
print('coverage',dict(counts),'remaining',len(missed),'examples',missed[:10],flush=True)
z0=next(Path(__file__).parent.glob('finite_logarithmic_multidegree_v07_PRIVATE_HOLD*.zip'));assert hashlib.sha256(z0.read_bytes()).hexdigest()=='ef40748e44e13280e00b4db496a3296119fa1adb2659afb869e5865f3765c6f4'
print('PASS frozen v0.7 SHA256',flush=True)

with tempfile.TemporaryDirectory() as tmp:
    with zipfile.ZipFile(z0) as zz:
        for filename in ('check_v07.py','compressed.py'):zz.extract(filename,tmp)
    sys.path.insert(0,tmp)
    from check_v07 import original
    from compressed import exact_M
    for aa in missed:
        nodes=[0]+list(aa)+[-v for v in aa]
        f,g=scalars(aa); M=exact_M(3,nodes)
        assert f and g and M[0][0]*M[1][1]-M[0][1]*M[1][0]==-f*g/8
        assert original(3,nodes)!=0
    print('PASS residual configurations: exact reduced and original determinants',len(missed),flush=True)
