# Research No. 81 — Reproducibility files

This bundle contains the unchanged mathematical source texts and exact symbolic certificates, plus the 2026-11-20 `CLOSURE_CHECKPOINT.md` with the D=2 reduction (section 2). **Historical PRIVATE/HOLD labels are kept as original-source provenance, not as the current audit decision.** No raw AI audit logs are included here.

## Main proof dependency sequence

1. `source/CLOSURE_CHECKPOINT.md` section 2: direct D=2 reduction from A to residue matrix M (original source; independent AI audit report in private evidence).
2. `source/symmetric_D2_radius_proof.md`: squared-radius formulas.
3. `source/symmetric_seven_2adic_proof.md`, `source/symmetric_seven_small_prime_proof.md`: local necessary conditions.
4. `source/symmetric_seven_global_proof.md`: global factorization obstruction.
5. `source/symmetric_seven_completion_proof.md`: Darmon–Merel reduction and final positive-polynomial contradiction.

`source/symmetric_seven_single_gcd_proof.md` is an optional earlier route, not used in the final proof.

## Execution

Use Python 3 and SymPy (the mathematical computer algebra dependency). For the short closing checks, from `certificates/`:

```powershell
python -m pip install sympy
python .\symmetric_seven_completion_certificate.py
python .\symmetric_seven_single_gcd_certificate.py
```

The other certificates may be more expensive and depend on the exactly preserved nested frozen `finite_logarithmic_multidegree_v07_PRIVATE_HOLD.zip`; do not replace it or modify its hash. These checks are not a substitute for reading the general proof or the independent AI audit reports. Python files are research reproducibility files, not security-reviewed production programs.

## External theorem

Darmon–Merel, *Winding Quotients and Some Variants of Fermat's Last Theorem*, Journal für die reine und angewandte Mathematik 490 (1997), 81–100. DOI: 10.1515/crll.1997.490.81. Only the needed statement is invoked; its proof is not reproduced.

NOVELTY INCONCLUSIVE. REFERENCES PARTIAL. NOT HUMAN PEER REVIEWED. All rights reserved.
